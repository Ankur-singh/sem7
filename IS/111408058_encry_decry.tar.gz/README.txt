The encryption-decryption algorithm used is Affine Cipher. The algorithm can encrypt any type of file, irrespective of the file format.
And after decryption the file format is also maintained and every other internal details of the file are taken care of.
To run the program:
	python encry_decry.py -e <filename> //The absolute file path has to be entered

	-d  = for decryption
	-e  = for encryption
	-help = for help 
